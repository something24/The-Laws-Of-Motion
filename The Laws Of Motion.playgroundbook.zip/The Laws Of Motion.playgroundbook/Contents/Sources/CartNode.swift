//
//  CartNode.swift

//
//  Created by Daniel Cosarca on 24/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//

import SpriteKit

public enum CartType {
    case carriage1
    case carriage2
    case carriage3
}
public enum EarthOrMars {
    case earth
    case mars
}
public enum FarOrClose {
    case close
    case far
}
//class CartNode initialises carts according to what scene they are needed for
public class CartNode: SKSpriteNode {
    var initialTouchPosition: CGPoint?
    var frontWheel = WheelNode(farOrClose: .close, wheelType: .front)
    var backWheel = WheelNode(farOrClose: .close, wheelType: .back)
    var newtonOnCart = NewtonOnCartNode(earthOrMars: .mars, farOrClose: .close)
    
    init(texture: SKTexture,color: UIColor,size: CGSize) {
        frontWheel = WheelNode.init(farOrClose: .close, wheelType: .front)
        backWheel = WheelNode.init(farOrClose: .close, wheelType: .back)
        newtonOnCart = NewtonOnCartNode.init(earthOrMars: .mars, farOrClose: .close)
        
        super.init(texture: texture, color: color, size: size)
    }
    //the convenience init below initialises cart according to their realm, type(weight) and the size of the carts if they are to be used in Chapter 4: Play
    convenience init(realm: EarthOrMars, cartType: CartType, farOrClose: FarOrClose){
        print("Cart initialise")
        
        switch realm {
        case .earth:
            
            switch cartType {
            case .carriage1:
                let carriageTexture = SKTexture(imageNamed: "Carriage")
                switch farOrClose {
                    
                case .far:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    frontWheel = WheelNode(farOrClose: .far, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .far, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .earth, farOrClose: .far)
                    self.position = CGPoint(x: 1240, y: 344.268)
                case .close:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: carriageTexture.size())
                       newtonOnCart = NewtonOnCartNode(earthOrMars: .earth, farOrClose: .close)
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: carriageTexture.size())
                    frontWheel = WheelNode(farOrClose: .close, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .close, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .earth, farOrClose: .close)
                    self.position = CGPoint(x: 338, y: -447)
                }
                physicsBody?.mass = 0.04
                
            case .carriage2:
                let carriageTexture = SKTexture(imageNamed: "Carriage1")
                switch farOrClose {
                case .far:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    frontWheel = WheelNode(farOrClose: .far, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .far, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .earth, farOrClose: .far)
                    self.position = CGPoint(x: 1251, y: 327.268)
                case .close:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: carriageTexture.size() )
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: carriageTexture.size())
                    frontWheel = WheelNode(farOrClose: .close, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .close, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .earth, farOrClose: .close)
                    self.position = CGPoint(x: 338, y: -447)
                }
                physicsBody?.mass = 0.05
            case .carriage3:
                let carriageTexture = SKTexture(imageNamed: "Carriage2")
                switch farOrClose {
                case .far:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    frontWheel = WheelNode(farOrClose: .far, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .far, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .earth, farOrClose: .far)
                
                    self.position = CGPoint(x: 1256, y: 344.268)
                case .close:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: carriageTexture.size() )
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: carriageTexture.size())
                    frontWheel = WheelNode(farOrClose: .close, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .close, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .earth, farOrClose: .close)
                    self.position = CGPoint(x: 338, y: -447)
                }
                physicsBody?.mass = 0.06
            }
        case .mars:
            switch cartType {
            case .carriage1:
                let carriageTexture = SKTexture(imageNamed: "CarriageSpace1")
                switch farOrClose {
                    
                case .far:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    frontWheel = WheelNode(farOrClose: .far, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .far, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .mars, farOrClose: .far)
                    self.position = CGPoint(x: 1256, y: 344.268)
                case .close:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: carriageTexture.size())
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .mars, farOrClose: .close)
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: carriageTexture.size())
                    self.position = CGPoint(x: 350, y: -422)
                    frontWheel = WheelNode(farOrClose: .close, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .close, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .mars, farOrClose: .close)
                }
                physicsBody?.mass = 0.04
            case .carriage2:
                let carriageTexture = SKTexture(imageNamed: "CarriageSpace2")
                switch farOrClose {
                case .far:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    frontWheel = WheelNode(farOrClose: .far, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .far, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .mars, farOrClose: .far)
          
                    self.position = CGPoint(x: 1256, y: 344.268)
                case .close:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: carriageTexture.size() )
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: carriageTexture.size())
                    self.position = CGPoint(x: 350, y: -422)
                    frontWheel = WheelNode(farOrClose: .close, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .close, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .mars, farOrClose: .close)
                    
                }
                physicsBody?.mass = 0.05
            case .carriage3:
                let carriageTexture = SKTexture(imageNamed: "CarriageSpace3")
                switch farOrClose {
                case .far:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: CGSize(width: carriageTexture.size().width / 2, height: carriageTexture.size().height / 2))
                    frontWheel = WheelNode(farOrClose: .far, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .far, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .mars, farOrClose: .far)
                    physicsBody?.mass = 0.06
                    self.position = CGPoint(x: 1256, y: 344.268)
                case .close:
                    self.init(texture: carriageTexture, color: UIColor.clear, size: carriageTexture.size() )
                    physicsBody = SKPhysicsBody(texture: carriageTexture, size: carriageTexture.size())
                    self.position = CGPoint(x: 350, y: -422)
                    frontWheel = WheelNode(farOrClose: .close, wheelType: .front)
                    backWheel = WheelNode(farOrClose: .close, wheelType: .back)
                    newtonOnCart = NewtonOnCartNode(earthOrMars: .mars, farOrClose: .close)
                    physicsBody?.mass = 0.06
                }
                physicsBody?.mass = 0.06
            }
        }
        
        physicsBody!.categoryBitMask =  PhysicsCategory.Carriage
        physicsBody!.collisionBitMask =  PhysicsCategory.Ground
        physicsBody?.allowsRotation = true
        isUserInteractionEnabled = true
        physicsBody?.affectedByGravity = true
        physicsBody?.friction = 0.1
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
