//
//  Wheel1.swift
//  Newton
//
//  Created by Daniel Cosarca on 25/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//

import SpriteKit

public enum WheelType {
    case front
    case back
}

public class WheelNode: SKSpriteNode{
    
    init(texture: SKTexture,color: UIColor,size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }
    convenience init(farOrClose: FarOrClose, wheelType: WheelType){
        print("Wheel initialising")
        let wheelTexture = SKTexture(imageNamed: "Wheel")
        switch farOrClose {
        case .close:
            self.init(texture: wheelTexture, color: UIColor.clear, size: wheelTexture.size())
            
            switch wheelType {
            case .front:
                self.position = CGPoint(x: 170, y: -536.5)
                physicsBody = SKPhysicsBody(circleOfRadius: wheelTexture.size().width / 2)
                physicsBody?.friction = 0.1
                
            case .back:
                self.position = CGPoint(x: 498, y: -536.5)
                physicsBody = SKPhysicsBody(circleOfRadius: wheelTexture.size().width / 2)
                physicsBody?.friction = 0.1
            }
        case .far:
            self.init(texture: wheelTexture, color: UIColor.clear, size: CGSize(width: wheelTexture.size().width / 2, height: wheelTexture.size().height / 2))
            switch wheelType {
            case .front:
                self.position = CGPoint(x: 1166.292, y: 284.5)
                physicsBody = SKPhysicsBody(circleOfRadius: wheelTexture.size().width / 4)
                 physicsBody?.friction = 0.25
            case .back:
                self.position = CGPoint(x: 1335.19, y: 284.5)
                physicsBody = SKPhysicsBody(circleOfRadius: wheelTexture.size().width / 4)
                       physicsBody?.friction = 0.25
            }
         
        }
        zPosition = 1
        physicsBody?.categoryBitMask = PhysicsCategory.Wheel
        physicsBody?.mass = 0.1
        physicsBody?.affectedByGravity = true
        physicsBody?.allowsRotation = true
        isUserInteractionEnabled = false
        

    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    

}
