//
//  Ground.swift
//
//  Created by Daniel Cosarca on 24/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//

import Foundation
import SpriteKit

public enum GroundType {
    case ground1
    case ground2
    case ground3
    case ground1Mars
    case background1
    case background2
    case background3
}
// The ground class sets the ground profiles for where apples, newton and the cart will be moving on. They have different collision bitmasks, and categories accordingly
public class GroundNode: SKSpriteNode {
    
    public override init(texture: SKTexture?, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }
    
    convenience init(groundType: GroundType) {
        print("Ground initialising")
        switch groundType {
        case .ground1:
            let groundTexture = SKTexture(imageNamed: "GroundScene1")
            self.init(texture: groundTexture, color: UIColor.clear, size: groundTexture.size())
            self.position = CGPoint(x: 134, y: -830)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: groundTexture.size())
        case .ground2:
            let groundTexture = SKTexture(imageNamed: "Ground2")
            self.init(texture: groundTexture, color: UIColor.clear, size: CGSize(width: groundTexture.size().width * 2, height: groundTexture.size().height))
            self.position = CGPoint(x: 0, y: -835)
            physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 2732, height: 378))
            //physicsBody?.friction = 0.1
        case .ground3:
            let groundTexture = SKTexture(imageNamed: "Ground3")
            self.init(texture: groundTexture, color: UIColor.clear, size: CGSize(width: groundTexture.size().width * 2, height: groundTexture.size().height))
            self.position = CGPoint(x: 503, y: -835)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: CGSize(width: groundTexture.size().width * 2, height: groundTexture.size().height))
        case .ground1Mars:
            let groundTexture = SKTexture(imageNamed: "GroundScene1Mars")
            self.init(texture: groundTexture, color: UIColor.clear, size: groundTexture.size())
            self.position = CGPoint(x: 129, y: -850)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: groundTexture.size())
        case .background1:
            let groundTexture = SKTexture(imageNamed: "GroundScene2Far")
            self.init(texture: groundTexture, color: UIColor.clear, size: groundTexture.size())
            self.position = CGPoint(x: -106, y: 55)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: groundTexture.size())
            
        case .background2:
            let groundTexture = SKTexture(imageNamed: "GroundScene3Far")
            self.init(texture: groundTexture, color: UIColor.clear, size: groundTexture.size())
            self.position = CGPoint(x: -14, y: -23)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: groundTexture.size())
        case .background3:
            let groundTexture = SKTexture(imageNamed: "GroundScene1Far")
            self.init(texture: groundTexture, color: UIColor.clear, size: groundTexture.size())
            self.position = CGPoint(x: -331.965, y: 151.821)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: groundTexture.size())
        }
        zPosition = -5
        physicsBody?.categoryBitMask = PhysicsCategory.Ground
        physicsBody?.collisionBitMask = PhysicsCategory.TheApple | PhysicsCategory.OtherApple | PhysicsCategory.Wheel
        physicsBody?.isDynamic = false
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
