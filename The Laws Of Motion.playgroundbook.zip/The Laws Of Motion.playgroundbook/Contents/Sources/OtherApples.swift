//fffff
//  OtherApples.swift
//  Newton
//
//  Created by Daniel Cosarca on 25/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//

//import Foundation
//import SpriteKit
//
//class OtherApplesNode: SKSpriteNode, EventListenerNode, InteractiveNode {
//    
//    func didMoveToScene() {
//        print("Apples added to scene")
//        let otherApplesTexture = SKTexture(imageNamed: "Apple1")
//        physicsBody = SKPhysicsBody(texture: otherApplesTexture, size: CGSize(width: otherApplesTexture.size().width/2, height: otherApplesTexture.size().height/2))
//        physicsBody!.categoryBitMask = PhysicsCategory.OtherApple
//        physicsBody!.collisionBitMask = PhysicsCategory.Ground
//        
//        isUserInteractionEnabled = true
//        physicsBody?.affectedByGravity = false
//        physicsBody?.friction = 0.05
//        
//    }
//    
//    func interact() {
//        physicsBody?.affectedByGravity = true
//        isUserInteractionEnabled = false
//    }
//    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
//        super.touchesEnded(touches, with: event)
//        print("Other apple tapped")
//        interact()
//    }
//}

