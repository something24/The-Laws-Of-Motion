//
//  Newton.swift

//
//  Created by Daniel Cosarca on 23/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//

import SpriteKit

//The NewtonNode class represents Newton presented in Law1, it's physics properties and textures
public class NewtonNode: SKSpriteNode {
    public override init(texture: SKTexture?, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }
    convenience init(earthOrMars: EarthOrMars) {
        var newtonTexture = SKTexture(imageNamed: "Newton reading")
        switch earthOrMars {
        case .earth:
            newtonTexture = SKTexture(imageNamed: "Newton reading")
        case .mars:
            newtonTexture = SKTexture(imageNamed: "Newton reading astronaut")
        }
        print("Man initialising")
        self.init(texture: newtonTexture, color: UIColor.clear, size: CGSize(width: 211.5, height: 394))
        self.physicsBody = SKPhysicsBody(texture: newtonTexture, size: CGSize(width: 211.5, height: 394))
        self.size = CGSize(width: 211.5, height: 394)
        self.position = CGPoint(x: 81.787, y: -517.295)
        self.physicsBody?.restitution = 0.3
        physicsBody?.isDynamic = false
        physicsBody!.categoryBitMask =  PhysicsCategory.Newton
        physicsBody!.collisionBitMask =  PhysicsCategory.TheApple
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
