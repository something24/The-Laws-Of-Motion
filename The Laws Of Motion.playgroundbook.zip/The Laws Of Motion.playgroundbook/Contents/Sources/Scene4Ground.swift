import Foundation
import SpriteKit
public enum CartOrNewton {
    case cart
    case newton
    case bottomOfHaystack
}
//Scene4Ground is the class which represents the ground profiles used in the play pages - GameScene4 and GameScene8. There actually are three different ground profile used in those screens, to make sure Newton can go in the haystack, while the cart can continue moving on the ground.
public class Scene4Ground: SKSpriteNode {
    public override init(texture: SKTexture?, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }
    
    convenience init(cartOrNewton: CartOrNewton) {
        let groundTexture = SKTexture(imageNamed: "ProfileMars")
        switch cartOrNewton {
        case .cart:
            let groundTexture = SKTexture(imageNamed: "ProfileMars")
            self.init(texture: groundTexture, color: UIColor.clear, size: groundTexture.size())
            self.position = CGPoint(x: 0, y: 107.862)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: groundTexture.size())
            physicsBody?.categoryBitMask = PhysicsCategory.Ground
            physicsBody?.collisionBitMask = PhysicsCategory.Carriage
        case .newton:
            let groundTexture = SKTexture(imageNamed: "ProfileMarsForNewton")
            self.init(texture: groundTexture, color: UIColor.clear, size: groundTexture.size())
            self.position = CGPoint(x: 1, y: 108)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: groundTexture.size())
            physicsBody?.categoryBitMask = PhysicsCategory.GroundForNewtonOnCart
            physicsBody?.collisionBitMask = PhysicsCategory.NewtonOnCart
        case .bottomOfHaystack:
            let groundTexture = SKTexture(imageNamed: "HaystackBottomForNewton")
            self.init(texture: groundTexture, color: UIColor.clear, size: groundTexture.size())
            self.position = CGPoint(x: -1267.5, y: 233)
            physicsBody = SKPhysicsBody(texture: groundTexture, size: groundTexture.size())
            physicsBody?.categoryBitMask = PhysicsCategory.BottomOfHaystack
            physicsBody?.collisionBitMask = PhysicsCategory.NewtonOnCart
        }
        zPosition = -6
        physicsBody?.isDynamic = false
        physicsBody?.friction = 0.2
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
