//

//  Newton
//
//  Created by Daniel Cosarca on 24/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.

//Haystack initialiser for GameScene7

import SpriteKit

public class Haystack: SKSpriteNode {
    override public init(texture: SKTexture?, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }
    convenience init() {
        print("Haystack initialising")
        let haystackTexture = SKTexture(imageNamed: "Haystack")
        self.init(texture: haystackTexture, color: UIColor.clear, size: haystackTexture.size())
//        self.physicsBody = SKPhysicsBody(texture: haystackTexture, size: haystackTexture.size())
        self.position = CGPoint(x: -310, y: -680)
        zPosition = 2
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

