import SpriteKit

//Class NewtonOnCartNode represents Newton in all scenes except Law1. The physics behaviour and sizes are defined
public class NewtonOnCartNode: SKSpriteNode {

    init(texture: SKTexture, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }

    convenience init(earthOrMars: EarthOrMars,farOrClose: FarOrClose) {
        print("Rider initialising")
        switch earthOrMars {
        case .earth:
            let riderTexture = SKTexture(imageNamed: "NewtonSitting")
            switch farOrClose {
            case .close:
                self.init(texture: riderTexture, color: UIColor.clear, size: riderTexture.size())
                physicsBody = SKPhysicsBody(texture: riderTexture, size: riderTexture.size())
                self.position = CGPoint(x: 152, y: -365)
            case .far:
                self.init(texture: riderTexture, color: UIColor.clear, size: CGSize(width: riderTexture.size().width/2, height: riderTexture.size().height/2))
                physicsBody = SKPhysicsBody(texture: riderTexture, size: CGSize(width: riderTexture.size().width/2, height: riderTexture.size().height/2))
                self.position = CGPoint(x: 1159.292, y: 371.2)
        }
        case .mars:
            let riderTexture = SKTexture(imageNamed: "NewtonSittingAstronaut")
            switch farOrClose {
            case .close:
                self.init(texture: riderTexture, color: UIColor.clear, size: riderTexture.size())
                physicsBody = SKPhysicsBody(texture: riderTexture, size: riderTexture.size())
                self.position = CGPoint(x: 153, y: -365)
            case .far:
                self.init(texture: riderTexture, color: UIColor.clear, size: CGSize(width: riderTexture.size().width/2, height: riderTexture.size().height/2))
                physicsBody = SKPhysicsBody(texture: riderTexture, size: CGSize(width: riderTexture.size().width/2, height: riderTexture.size().height/2))
                self.position = CGPoint(x: 1159.292, y: 371.2)
        }
        }

        zPosition = 2
        physicsBody?.categoryBitMask = PhysicsCategory.Newton
        physicsBody?.collisionBitMask = PhysicsCategory.Ground
        
        physicsBody?.mass = 0.03
        physicsBody?.affectedByGravity = true
        physicsBody?.allowsRotation = true
        isUserInteractionEnabled = false

    }
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

