//
//  GameScene.swift
//
//
//  Created by Daniel Cosarca on 23/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//

import SpriteKit
import GameplayKit

struct PhysicsCategory {
    static let TheApple: UInt32 = 0
    static let OtherApple: UInt32 = 0b1
    static let Newton: UInt32 = 0b10
    static let Ground: UInt32 = 0b100
    static let NewtonSpace: UInt32 = 0b1000
    static let Carriage: UInt32 = 0b10000
    static let Wheel: UInt32 = 0b100000
    static let NewtonOnCart: UInt32 = 0b1000000
    static let GroundForNewtonOnCart: UInt32 = 0b1000000
    static let BottomOfHaystack: UInt32 = 0b1000000
}

protocol InteractiveNode {
    func interact()
}
//Game Scene 1 is the Scene class for Law 1 - Mars

public class GameScene1: SKScene,SKPhysicsContactDelegate {
    var sceneRealm: Int?
    var newtonNode = NewtonNode.init(earthOrMars: .mars)
    var theAppleNode = AppleNode.init(earthOrMars: .mars, appleType: .theAppleMars, farOrClose: .close)
    var appleNode1 = AppleNode.init(earthOrMars: .mars, appleType: .apple4, farOrClose: .close)
    var appleNode2 = AppleNode.init(earthOrMars: .mars, appleType: .apple5, farOrClose: .close)
    var appleNode3 = AppleNode.init(earthOrMars: .mars, appleType: .apple6, farOrClose: .far)
    var appleNode4 = AppleNode.init(earthOrMars: .mars, appleType: .apple7, farOrClose: .far)
    
    override public func didMove(to view: SKView) {
        physicsWorld.gravity = CGVector(dx: 0, dy: -3.711)
        addChild(theAppleNode)
        addChild(appleNode1)
        addChild(appleNode2)
        addChild(appleNode3)
        addChild(newtonNode)
        addChild(appleNode4)
        let groundNode = GroundNode.init(groundType: .ground1Mars)
        let groundNodeFar = GroundNode.init(groundType: .background3)
        addChild(groundNode)
        addChild((groundNodeFar))
        physicsWorld.contactDelegate = self
    }

    //Collision detection for when the apple hits Newton, when this happens, Newton's texture is changed
    var noCollision = true
    public func didBegin(_ contact: SKPhysicsContact) {
        guard noCollision else { return }
        let collision = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        if collision == PhysicsCategory.Newton | PhysicsCategory.TheApple {
            newtonNode.texture = SKTexture(imageNamed: "Newton reading auch astronaut")
            print("AUCH!")
            
            noCollision = false
        }
    }
}

//Game Scene 2 is the Scene class for Law 2 - Mars
public class GameScene2: SKScene {
    var initialTouchPosition: CGPoint?
    var cartNode = CartNode.init(realm: .mars, cartType: .carriage3, farOrClose: .close)
    
    //function changeCartNode() is used to change the weight and type of the carriage
    public func changeCartNode(numberOfCarriage: Int) {
        switch numberOfCarriage {
        case 1:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage1, farOrClose: .close)
        case 2:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage2, farOrClose: .close)
        case 3:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage3, farOrClose: .close)
        default:
            return
        }
    }
    override public func didMove(to view: SKView) {
       self.physicsWorld.gravity = CGVector(dx: 0, dy: -3.711)
        let groundNode = GroundNode.init(groundType: .ground2)
        let groundFarNode = GroundNode.init(groundType: .background1)
        let appleNode1 = AppleNode.init(earthOrMars: .mars, appleType: .apple8, farOrClose: .far)
        let appleNode2 = AppleNode.init(earthOrMars: .mars, appleType: .apple9, farOrClose: .far)
        let appleNode3 = AppleNode.init(earthOrMars: .mars, appleType: .apple10, farOrClose: .far)
        let appleNode4 = AppleNode.init(earthOrMars: .mars, appleType: .apple11, farOrClose: .far)
        
        
        addChild(cartNode)
        addChild(cartNode.newtonOnCart)
        addChild(appleNode1)
        addChild(appleNode2)
        addChild(appleNode3)
        addChild(appleNode4)
        addChild(cartNode.frontWheel)
        addChild(cartNode.backWheel)
        addChild(groundNode)
        addChild(groundFarNode)
        
        //creating pin joins for attaching the wheels to the body of the cart, and to attach newton to the cart
        let joint1 = SKPhysicsJointPin.joint(withBodyA: cartNode.frontWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.frontWheel.position)

        let joint2 = SKPhysicsJointPin.joint(withBodyA: cartNode.backWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.backWheel.position)
        scene?.physicsWorld.add(joint1)
        scene?.physicsWorld.add(joint2)

        let joint3 = SKPhysicsJointFixed.joint(withBodyA: cartNode.physicsBody!, bodyB: cartNode.newtonOnCart.physicsBody!, anchor: cartNode.newtonOnCart.position)
        scene?.physicsWorld.add(joint3)
    }
   
    //touchesBegan is used to detect when a tap takes place on screen, and applies a force on the body of the carriage
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            cartNode.physicsBody?.applyForce(CGVector(dx: -2500, dy: -25), at: cartNode.position)
        }
    }
}

//Game Scene 3 is the Scene class for Law 3 - Mars:
public class GameScene3: SKScene {
    
    var initialTouchPosition: CGPoint?
    var cartNode = CartNode.init(realm: .mars, cartType: .carriage3, farOrClose: .close)
    var joint3 = SKPhysicsJointFixed()
    var ejectionForce = CGVector(dx: -600, dy: 600)
    var ejectionForceCart = CGVector(dx: 1800, dy: -300)
    public func changeCartNode(numberOfCarriage: Int) {
        switch numberOfCarriage {
        case 1:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage1, farOrClose: .close)
        case 2:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage2, farOrClose: .close)
        case 3:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage3, farOrClose: .close)
        default:
            return
        }
    }
    public func changeEjection(numberOfForce: Int) {
        switch numberOfForce {
        case 1:
            ejectionForce = CGVector(dx: -330, dy: 330)
            ejectionForceCart = CGVector(dx: 900, dy: -200)
        case 2:
            ejectionForce = CGVector(dx: -600, dy: 600)
            ejectionForceCart = CGVector(dx: 1800, dy: -300)
        case 3:
            ejectionForce = CGVector(dx: -1200, dy: 900)
            ejectionForceCart = CGVector(dx: 2700, dy: -500)
        default:
            return
        }
    }
    override public func didMove(to view: SKView) {
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -3.711)
        let groundNode = GroundNode.init(groundType: .ground3)
        let groundFarNode = GroundNode.init(groundType: .background2)
        let haystack = Haystack.init()
        haystack.texture = SKTexture(imageNamed: "HaystackScene3")
        haystack.zPosition = 3
        let apple1 = AppleNode.init(earthOrMars: .mars, appleType: .apple12, farOrClose: .far)
        let apple2 = AppleNode.init(earthOrMars: .mars, appleType: .apple13, farOrClose: .far)
        let apple3 = AppleNode.init(earthOrMars: .mars, appleType: .apple14, farOrClose: .far)
        let apple4 = AppleNode.init(earthOrMars: .mars, appleType: .apple15, farOrClose: .far)
        
        addChild(apple1)
        addChild(apple2)
        addChild(apple3)
        addChild(apple4)
        
        addChild(cartNode)
        addChild(cartNode.frontWheel)
        addChild(cartNode.backWheel)
        addChild(cartNode.newtonOnCart)
        addChild(groundNode)
        addChild(groundFarNode)
        addChild(haystack)
        
        //creating pin joins for attaching the wheels to the body of the cart, and to attach newton to the cart
        let joint1 = SKPhysicsJointPin.joint(withBodyA: cartNode.frontWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.frontWheel.position)

        let joint2 = SKPhysicsJointPin.joint(withBodyA: cartNode.backWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.backWheel.position)
        scene?.physicsWorld.add(joint1)
        scene?.physicsWorld.add(joint2)
        
        joint3 = SKPhysicsJointFixed.joint(withBodyA: cartNode.physicsBody!, bodyB: cartNode.newtonOnCart.physicsBody!, anchor: cartNode.newtonOnCart.position)
        scene?.physicsWorld.add(joint3)
    }
    
     //touchesBegan and touchesEnded are used to detect when a swipe left takes place on screen, and applies a force on the body of the carriage and on Newton and removes joint3
     override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         for touch in touches {
            initialTouchPosition = touch.location(in: self)
        }
    }
    var happened = false
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let touchPosition = touch.location(in: self)
            guard touchPosition.x < initialTouchPosition!.x - 10 else {
                return
            }
            guard !happened else {return}
            //print("ola")
            scene?.physicsWorld.remove(joint3)
            cartNode.newtonOnCart.texture = SKTexture(imageNamed: "NewtonSittingHandsUpAstronaut")
            cartNode.newtonOnCart.physicsBody?.applyForce(ejectionForce)
            cartNode.newtonOnCart.physicsBody?.applyTorque(CGFloat(1))
            cartNode.physicsBody?.applyForce(ejectionForceCart, at: position)
            happened = true
        }
    }
}

//GameScene4 is the Scene class for the play screen - Mars
public class GameScene4: SKScene,SKPhysicsContactDelegate {
    var initialTouchPosition: CGPoint?
    var cartNode = CartNode(realm: .mars, cartType: .carriage3, farOrClose: .far)
    var joint3 = SKPhysicsJointFixed()
    var force = CGVector(dx: -800 , dy: -200)
    var ejectionForce = CGVector(dx: -180, dy: 180)
    var ejectionForceCart = CGVector(dx: 400, dy: 0)
    public func changeCartNode(numberOfCarriage: Int) {
        switch numberOfCarriage {
        case 1:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage1, farOrClose: .far)
        case 2:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage2, farOrClose: .far)
        case 3:
            cartNode = CartNode.init(realm: .mars, cartType: .carriage3, farOrClose: .far)
        default:
            return
        }
    }
    public func changeForce(numberOfForce: Int) {
        switch numberOfForce {
        case 1:
            force = CGVector(dx: -400, dy: -100)
        case 2:
            force = CGVector(dx: -800, dy: -200)
        case 3:
            force = CGVector(dx: -1200, dy: -300)
        default:
            return
        }
    }
    public func changeEjection(numberOfForce: Int) {
        switch numberOfForce {
        case 1:
            ejectionForce = CGVector(dx: -120, dy: 120)
            ejectionForceCart = CGVector(dx: 270, dy: -10)
        case 2:
            ejectionForce = CGVector(dx: -180, dy: 180)
            ejectionForceCart = CGVector(dx: 400, dy: -15)
        case 3:
            ejectionForce = CGVector(dx: -700, dy: -700)
            ejectionForceCart = CGVector(dx: 800, dy: -20)
        default:
            return
        }
    }
    override public func didMove(to view: SKView) {
        cartNode.newtonOnCart.physicsBody?.categoryBitMask = PhysicsCategory.NewtonOnCart
        cartNode.newtonOnCart.physicsBody?.collisionBitMask = PhysicsCategory.GroundForNewtonOnCart
        cartNode.newtonOnCart.physicsBody?.contactTestBitMask = PhysicsCategory.BottomOfHaystack
        
        
        physicsWorld.gravity = CGVector(dx: 0, dy: -3.711)

        
        let groundNode = Scene4Ground.init(cartOrNewton: .cart)
        let newtonGroundNode = Scene4Ground.init(cartOrNewton: .newton)
        let bottomOfHaystack = Scene4Ground.init(cartOrNewton: .bottomOfHaystack)
        physicsWorld.contactDelegate = self as! SKPhysicsContactDelegate

        
        addChild(groundNode)
        addChild(newtonGroundNode)
        addChild(bottomOfHaystack)
        addChild(cartNode)
        addChild(cartNode.frontWheel)
        addChild(cartNode.backWheel)
        addChild(cartNode.newtonOnCart)
        
        
        let joint1 = SKPhysicsJointPin.joint(withBodyA: cartNode.frontWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.frontWheel.position)
        
        let joint2 = SKPhysicsJointPin.joint(withBodyA: cartNode.backWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.backWheel.position)
        scene?.physicsWorld.add(joint1)
        scene?.physicsWorld.add(joint2)
        
        joint3 = SKPhysicsJointFixed.joint(withBodyA: cartNode.physicsBody!, bodyB: cartNode.newtonOnCart.physicsBody!, anchor: cartNode.newtonOnCart.position)
        scene?.physicsWorld.add(joint3)
        
    }
    
    //Collision detection - when newton touches the bottom of the haystack, the Newton child is removed from the scene, and a message comes up to inform the user of hitting their target
    var noCollision = true

    public func didBegin(_ contact: SKPhysicsContact) {
        guard noCollision else { return }
        let collision = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask

        if collision == (PhysicsCategory.NewtonOnCart | PhysicsCategory.BottomOfHaystack) && cartNode.newtonOnCart.position.x < -1120{
            cartNode.newtonOnCart.removeFromParent()
            print("AUCH!")
            noCollision = false
            let congrats = SKLabelNode(fontNamed: "Copperplate")
            congrats.text = "Well done!"
            congrats.fontSize = 64
            congrats.fontColor = SKColor.black
            congrats.position = CGPoint(x: 400, y: -600)

            addChild(congrats)
        }
    }
    
    //touchesBegan and touchesEnded are used to detect when a swipe left or tap gesture takes place on screen, and applies a force on the body of the carriage and on Newton and removes joint3
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        for touch in touches {
            initialTouchPosition = touch.location(in: self)
            cartNode.physicsBody?.applyForce(force, at: cartNode.position)

        }
    }
    
    var happened: Bool = false
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
        let touchPosition = touch.location(in: self)
        guard touchPosition.x < initialTouchPosition!.x - 7 else {
            return
        }

            guard !happened else {return}
        print("ola")
        scene?.physicsWorld.remove(joint3)
        cartNode.newtonOnCart.texture = SKTexture(imageNamed: "NewtonSittingHandsUpAstronaut")
        cartNode.newtonOnCart.physicsBody?.applyForce(ejectionForce)
        cartNode.newtonOnCart.physicsBody?.applyTorque(CGFloat(1))
        cartNode.physicsBody?.applyForce(ejectionForceCart, at: position)
            happened = true
        
        }
    }
}
//GameScene5 is the Scene class for Law 1 - Earth
public class GameScene5: SKScene,SKPhysicsContactDelegate {
    
    let newtonNode = NewtonNode.init(earthOrMars: .earth)
    
    override public func didMove(to view: SKView) {
        physicsWorld.gravity = CGVector(dx: 0, dy: -9.8)
        let theAppleNode = AppleNode.init(earthOrMars: .earth, appleType: .theApple, farOrClose: .close)
        let appleNode1 = AppleNode.init(earthOrMars: .earth, appleType: .apple1, farOrClose: .close)
        let appleNode2 = AppleNode.init(earthOrMars: .earth, appleType: .apple2, farOrClose: .close)
        let appleNode3 = AppleNode.init(earthOrMars: .earth, appleType: .apple3, farOrClose: .close)
        let appleNode6 = AppleNode.init(earthOrMars: .earth, appleType: .apple6, farOrClose: .far)
        let appleNode7 = AppleNode.init(earthOrMars: .earth, appleType: .apple7, farOrClose: .far)
        let groundNodeFar = GroundNode.init(groundType: .background3)
        addChild(theAppleNode)
        addChild(appleNode1)
        addChild(appleNode2)
        addChild(appleNode3)
        addChild(newtonNode)
        addChild(appleNode6)
        addChild(appleNode7)
        let groundNode = GroundNode.init(groundType: .ground1)
        addChild(groundNode)
        addChild(groundNodeFar)
        
        physicsWorld.contactDelegate = self
    }
    
    //Collision detection for when the apple hits Newton, when this happens, Newton's texture is changed
    var noCollision = true
    
    public func didBegin(_ contact: SKPhysicsContact) {
        guard noCollision else { return }
        let collision = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        if collision == PhysicsCategory.Newton | PhysicsCategory.TheApple {
            newtonNode.texture = SKTexture(imageNamed: "Newton reading auch")
            print("AUCH!")
            
            noCollision = false
        }
    }
}

//GameScene6 is the Scene class for Law 2 - Earth
public class GameScene6: SKScene {
    var initialTouchPosition: CGPoint?
    var cartNode = CartNode.init(realm: .earth, cartType: .carriage2, farOrClose: .close)
    
    public func changeCartNode(numberOfCarriage: Int) {
        switch numberOfCarriage {
        case 1:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage1, farOrClose: .close)
        case 2:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage2, farOrClose: .close)
        case 3:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage3, farOrClose: .close)
        default:
            return
        }
    }
    override public func didMove(to view: SKView) {
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -9.8)
        let groundNode = GroundNode.init(groundType: .ground2)
        let groundFarNode = GroundNode.init(groundType: .background1)
        let appleNode1 = AppleNode.init(earthOrMars: .earth, appleType: .apple8, farOrClose: .far)
        let appleNode2 = AppleNode.init(earthOrMars: .earth, appleType: .apple9, farOrClose: .far)
        let appleNode3 = AppleNode.init(earthOrMars: .earth, appleType: .apple10, farOrClose: .far)
        let appleNode4 = AppleNode.init(earthOrMars: .earth, appleType: .apple11, farOrClose: .far)
        
        addChild(cartNode)
        addChild(cartNode.newtonOnCart)
        addChild(appleNode1)
        addChild(appleNode2)
        addChild(appleNode3)
        addChild(appleNode4)
        addChild(cartNode.frontWheel)
        addChild(cartNode.backWheel)
        addChild(groundNode)
        addChild(groundFarNode)
        //Creating Joints
        let joint1 = SKPhysicsJointPin.joint(withBodyA: cartNode.frontWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.frontWheel.position)
        
        let joint2 = SKPhysicsJointPin.joint(withBodyA: cartNode.backWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.backWheel.position)
        scene?.physicsWorld.add(joint1)
        scene?.physicsWorld.add(joint2)
        
        let joint3 = SKPhysicsJointFixed.joint(withBodyA: cartNode.physicsBody!, bodyB: cartNode.newtonOnCart.physicsBody!, anchor: cartNode.newtonOnCart.position)
        scene?.physicsWorld.add(joint3)
        
    }
    
    //touchesBegan is used to detect when a tap takes place on screen, and applies a force on the body of the carriage
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            cartNode.physicsBody?.applyForce(CGVector(dx: -2500, dy: -25), at: cartNode.position)
        }
    }
}
//GameScene7 is the Scene class for Law 3 - Earth
public class GameScene7: SKScene {
    var initialTouchPosition: CGPoint?
    var cartNode = CartNode.init(realm: .earth, cartType: .carriage2, farOrClose: .close)
    var joint3 = SKPhysicsJointFixed()
    var ejectionForce = CGVector(dx: -600, dy: 600)
    var ejectionForceCart = CGVector(dx: 1800, dy: -300)
    public func changeCartNode(numberOfCarriage: Int) {
        switch numberOfCarriage {
        case 1:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage1, farOrClose: .close)
        case 2:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage2, farOrClose: .close)
        case 3:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage3, farOrClose: .close)
        default:
            return
        }
    }
    public func changeEjection(numberOfForce: Int) {
        switch numberOfForce {
        case 1:
            ejectionForce = CGVector(dx: -330, dy: 330)
            ejectionForceCart = CGVector(dx: 900, dy: -200)
        case 2:
            ejectionForce = CGVector(dx: -600, dy: 600)
            ejectionForceCart = CGVector(dx: 1800, dy: -300)
        case 3:
            ejectionForce = CGVector(dx: -1200, dy: 900)
            ejectionForceCart = CGVector(dx: 2700, dy: -500)
        default:
            return
        }
    }
    override public func didMove(to view: SKView) {
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -9.8)
        let groundNode = GroundNode.init(groundType: .ground3)
        let groundFarNode = GroundNode.init(groundType: .background2)
        groundFarNode.position = CGPoint(x: 0, y: -32)
        let haystack = Haystack.init()
        haystack.zPosition = 3
        let apple1 = AppleNode.init(earthOrMars: .earth, appleType: .apple12, farOrClose: .far)
        let apple2 = AppleNode.init(earthOrMars: .earth, appleType: .apple13, farOrClose: .far)
        let apple3 = AppleNode.init(earthOrMars: .earth, appleType: .apple14, farOrClose: .far)
        let apple4 = AppleNode.init(earthOrMars: .earth, appleType: .apple15, farOrClose: .far)

        addChild(apple1)
        addChild(apple2)
        addChild(apple3)
        addChild(apple4)
        addChild(cartNode)
        addChild(cartNode.frontWheel)
        addChild(cartNode.backWheel)
        addChild(cartNode.newtonOnCart)
        addChild(groundNode)
        addChild(groundFarNode)
        addChild(haystack)
        
        //Creating joints
        let joint1 = SKPhysicsJointPin.joint(withBodyA: cartNode.frontWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.frontWheel.position)
        
        let joint2 = SKPhysicsJointPin.joint(withBodyA: cartNode.backWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.backWheel.position)
        scene?.physicsWorld.add(joint1)
        scene?.physicsWorld.add(joint2)
        
        joint3 = SKPhysicsJointFixed.joint(withBodyA: cartNode.physicsBody!, bodyB: cartNode.newtonOnCart.physicsBody!, anchor: cartNode.newtonOnCart.position)
        scene?.physicsWorld.add(joint3)
    }
    
    //using touchesBegan and touchesEnded for swipe left recognition, which removes joint3
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            initialTouchPosition = touch.location(in: self)
        }
    }
    var happened = false
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let touchPosition = touch.location(in: self)
            guard touchPosition.x < initialTouchPosition!.x - 10 else {
                return
            }
            guard !happened else {return}
            print("ola")
            scene?.physicsWorld.remove(joint3)
            cartNode.newtonOnCart.texture = SKTexture(imageNamed: "NewtonSittingHandsUp")
            cartNode.newtonOnCart.physicsBody?.applyForce(ejectionForce)
            cartNode.newtonOnCart.physicsBody?.applyTorque(CGFloat(1))
            cartNode.physicsBody?.applyForce(ejectionForceCart, at: position)
            happened = true
        }
    }
}

//GameScene8 is the Scene class for the Play screen - earth
public class GameScene8: SKScene,SKPhysicsContactDelegate {
    var initialTouchPosition: CGPoint?
    var cartNode = CartNode(realm: .earth, cartType: .carriage2, farOrClose: .far)
    var joint3 = SKPhysicsJointFixed()
    var force = CGVector(dx: -800 , dy: -40)
    var ejectionForce = CGVector(dx: -180, dy: 180)
    var ejectionForceCart = CGVector(dx: 400, dy: -20)
    //functions to change forces and cart types.
    public func changeCartNode(numberOfCarriage: Int) {
        switch numberOfCarriage {
        case 1:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage1, farOrClose: .far)
        case 2:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage2, farOrClose: .far)
        case 3:
            cartNode = CartNode.init(realm: .earth, cartType: .carriage3, farOrClose: .far)
        default:
            return
        }
    }
    public func changeForce(numberOfForce: Int) {
        switch numberOfForce {
        case 1:
            force = CGVector(dx: -400, dy: -100)
        case 2:
            force = CGVector(dx: -800, dy: -200)
        case 3:
            force = CGVector(dx: -1200, dy: -300)
        default:
            return
        }
    }
    public func changeEjection(numberOfForce: Int) {
        switch numberOfForce {
        case 1:
            ejectionForce = CGVector(dx: -120, dy: 120)
            ejectionForceCart = CGVector(dx: 270, dy: -10)
        case 2:
            ejectionForce = CGVector(dx: -180, dy: 180)
            ejectionForceCart = CGVector(dx: 400, dy: -15)
        case 3:
            ejectionForce = CGVector(dx: -700, dy: -700)
            ejectionForceCart = CGVector(dx: 600, dy: -20)
        default:
            return
        }
    }
    override public func didMove(to view: SKView) {
                cartNode.newtonOnCart.physicsBody?.categoryBitMask = PhysicsCategory.NewtonOnCart
                cartNode.newtonOnCart.physicsBody?.collisionBitMask = PhysicsCategory.GroundForNewtonOnCart
                cartNode.newtonOnCart.physicsBody?.contactTestBitMask = PhysicsCategory.BottomOfHaystack
        
        
        physicsWorld.gravity = CGVector(dx: 0, dy: -9.8)
        
        
        let groundNode = Scene4Ground.init(cartOrNewton: .cart)
        let newtonGroundNode = Scene4Ground.init(cartOrNewton: .newton)
        let bottomOfHaystack = Scene4Ground.init(cartOrNewton: .bottomOfHaystack)
        physicsWorld.contactDelegate = self as! SKPhysicsContactDelegate
    
        addChild(groundNode)
        addChild(newtonGroundNode)
        addChild(bottomOfHaystack)
        addChild(cartNode.newtonOnCart)
        addChild(cartNode)
        addChild(cartNode.frontWheel)
        addChild(cartNode.backWheel)
        
        //creating physics joints
        let joint1 = SKPhysicsJointPin.joint(withBodyA: cartNode.frontWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.frontWheel.position)
        
        let joint2 = SKPhysicsJointPin.joint(withBodyA: cartNode.backWheel.physicsBody!, bodyB: cartNode.physicsBody!, anchor: cartNode.backWheel.position)
        scene?.physicsWorld.add(joint1)
        scene?.physicsWorld.add(joint2)
        
        joint3 = SKPhysicsJointFixed.joint(withBodyA: cartNode.physicsBody!, bodyB: cartNode.newtonOnCart.physicsBody!, anchor: cartNode.newtonOnCart.position)
        scene?.physicsWorld.add(joint3)
    }
    
        //Collision detection - when newton touches the bottom of the haystack, the Newton child is removed from the scene, and a message comes up to inform the user of hitting their target
        var noCollision = true
        public func didBegin(_ contact: SKPhysicsContact) {
            guard noCollision else { return }
            let collision = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
            if (collision == (PhysicsCategory.BottomOfHaystack | PhysicsCategory.NewtonOnCart)) && cartNode.newtonOnCart.position.x < -1120 {
                cartNode.newtonOnCart.removeFromParent()
                //print("AUCH!")
                noCollision = false
                let congrats = SKLabelNode(fontNamed: "Copperplate")
                congrats.text = "Well done!"
                congrats.fontSize = 64
                congrats.fontColor = SKColor.black
                congrats.position = CGPoint(x: 400, y: -600)

                addChild(congrats)
            }
        }
    //Gesture recognition which applies forces and removes joint3
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            initialTouchPosition = touch.location(in: self)
            cartNode.physicsBody?.applyForce(force, at: cartNode.position)
            
        }
    }
//    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
//        print("hi")
//        
//        for touch in touches {
//            
//            //cartNode.physicsBody?.applyForce(CGVector(dx: -50, dy: -5), at: position)
//        }
//    }
    var happened: Bool = false
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let touchPosition = touch.location(in: self)
            guard touchPosition.x < initialTouchPosition!.x - 10 else {
                return
            }
            
            guard !happened else {return}
            print("ola")
            scene?.physicsWorld.remove(joint3)
            cartNode.newtonOnCart.texture = SKTexture(imageNamed: "NewtonSittingHandsUpAstronaut")
            cartNode.newtonOnCart.physicsBody?.applyForce(ejectionForce)
            cartNode.newtonOnCart.physicsBody?.applyTorque(CGFloat(1))
            cartNode.physicsBody?.applyForce(ejectionForceCart)
            happened = true
            
        }
    }
}
