//
//  GameViewController.swift
//  
//
//  Created by Daniel Cosarca on 23/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

public class GameViewController: UIViewController {
//    override public func viewWillLayoutSubviews() {
//        let hello: Int
//    }
    override public func viewWillAppear(_ animated: Bool) {
        print("hi")
        if let view = self.view as! SKView? {
            // Load the SKScene from '1.sks'
            if let scene = SKScene(fileNamed: "GameScene4") {
                // Set the scale mode to scale to fit the window
                
                scene.scaleMode = .aspectFit

                // Present the scene
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
            
            view.showsFPS = true
            view.showsNodeCount = true
            view.showsPhysics = false
        }
    }
    
    override public var shouldAutorotate: Bool {
        return true
    }

    override public var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override public func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    override public var prefersStatusBarHidden: Bool {
        return true
    }
}
