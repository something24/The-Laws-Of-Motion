//
//  Apple.swift
//
//  Created by Daniel Cosarca on 23/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//


import SpriteKit

//Creating different enums for different apples
public enum AppleType {
    case theApple
    case theAppleMars
    case apple1
    case apple2
    case apple3
    case apple4
    case apple5
    case apple6
    case apple7
    case apple8
    case apple9
    case apple10
    case apple11
    case apple12
    case apple13
    case apple14
    case apple15
}
public class AppleNode: SKSpriteNode, InteractiveNode {
    
    init(texture: SKTexture,color: UIColor,size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }
    //in the convenience init apple textures and physics bodies are initialised according to their realm, type and size
    convenience init(earthOrMars: EarthOrMars, appleType: AppleType, farOrClose: FarOrClose){
        print("Apple initialising")
        
        //the switch below choses textures and sizes according to their realm, and if they are far or close on the display
        switch earthOrMars {
        case .earth:
            let appleTexture = SKTexture(imageNamed: "Apple1")
            switch farOrClose {
            case .far:
                self.init(texture: appleTexture, color: UIColor.clear, size: CGSize(width: appleTexture.size().width / 4, height: appleTexture.size().height / 4))
                physicsBody = SKPhysicsBody(texture: appleTexture, size: CGSize(width: appleTexture.size().width/4, height: appleTexture.size().height/4))
            case .close:
            self.init(texture: appleTexture, color: UIColor.clear, size: CGSize(width: appleTexture.size().width / 2.5, height: appleTexture.size().height / 2.5))
            physicsBody = SKPhysicsBody(texture: appleTexture, size: CGSize(width: appleTexture.size().width/2.5, height: appleTexture.size().height/2.5))
            }
        case .mars:
            
            let appleTexture = SKTexture(imageNamed: "AppleRobotic")
            switch farOrClose {
            case .far:
                self.init(texture: appleTexture, color: UIColor.clear, size: CGSize(width: appleTexture.size().width / 2, height: appleTexture.size().height / 2))
                physicsBody = SKPhysicsBody(texture: appleTexture, size: CGSize(width: appleTexture.size().width/2, height: appleTexture.size().height/2))
            case .close:
                self.init(texture: appleTexture, color: UIColor.clear, size: CGSize(width: appleTexture.size().width / 1.3, height: appleTexture.size().height / 1.3))
                physicsBody = SKPhysicsBody(texture: appleTexture, size: CGSize(width: appleTexture.size().width / 1.3, height: appleTexture.size().height / 1.3))
            }
        }
        //The switch below sets different physics properties to apples according to what they are used for.
        switch appleType {
        case .theApple:
            self.position = CGPoint(x: 75.6, y: 0)
            physicsBody!.categoryBitMask =  PhysicsCategory.TheApple
            physicsBody!.contactTestBitMask = PhysicsCategory.Newton
           physicsBody?.friction = 0.25
        case .theAppleMars:
            self.position = CGPoint(x: 97, y: -191.53)
            physicsBody!.categoryBitMask =  PhysicsCategory.TheApple
            physicsBody!.contactTestBitMask = PhysicsCategory.Newton
            physicsBody?.friction = 0.2
//            physicsBody?.restitution = 0.2
        case .apple1:
            self.position = CGPoint(x: 257, y: 189.5)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.16
        case .apple2:
            self.position = CGPoint(x: 338, y: -62)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.16
        case .apple3:
            self.position = CGPoint(x: 485, y: 20)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple4:
            self.position = CGPoint(x: 307, y: -152)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple5:
            self.position = CGPoint(x: 418, y: -209.53)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple6:
            self.position = CGPoint(x: -397, y: 428)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple7:
            self.position = CGPoint(x: -223, y: 399)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple8:
            self.position = CGPoint(x: -435, y: 335)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple9:
            self.position = CGPoint(x: -264, y: 304)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple10:
            self.position = CGPoint(x: 158, y: 253)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple11:
            self.position = CGPoint(x: 274.629, y: 203.255)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple12:
            self.position = CGPoint(x: -320, y: 288)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple13:
            self.position = CGPoint(x: -152, y: 260)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple14:
            self.position = CGPoint(x: 313, y: 138)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        case .apple15:
            self.position = CGPoint(x: 481, y: 131)
            physicsBody!.categoryBitMask =  PhysicsCategory.OtherApple
            physicsBody?.friction = 0.2
        }

        physicsBody!.collisionBitMask =  PhysicsCategory.Newton | PhysicsCategory.Ground
        isUserInteractionEnabled = true
        physicsBody?.affectedByGravity = false
        //physicsBody?.friction = 0.16
        physicsBody?.mass = 0.01
        physicsBody?.restitution = 0.18
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func didMoveToScene() {
    }
    
    //function to make the apple fall
    func interact() {
        physicsBody?.affectedByGravity = true
        isUserInteractionEnabled = false
   }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        print("apple tapped")
        interact()
    }
}

