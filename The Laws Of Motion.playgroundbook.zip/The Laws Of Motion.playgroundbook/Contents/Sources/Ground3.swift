//
//  Ground3.swift
//  Newton
//
//  Created by Daniel Cosarca on 26/03/2018.
//  Copyright © 2018 Daniel Cosarca. All rights reserved.
//

//import SpriteKit
//
//public class GroundNode3: SKSpriteNode, EventListenerNode {
//    func didMoveToScene() {
//        print("ground added to scene")
//        name = "Ground2"
//        physicsBody?.categoryBitMask = PhysicsCategory.Ground
//        physicsBody?.collisionBitMask = PhysicsCategory.Carriage | PhysicsCategory.Wheel
//        physicsBody?.isDynamic = false
//        physicsBody?.friction = 0.2
//    }
//    
//}


