
/*:
 ## **Let's play!**
 
 I'm glad to say that's it for the learning today.
 
 In this page, you can play by driving the cart around, but also by ejecting Sir Isaac Newton as you please. I recommend you use this in **fullscreen landscape** mode to enjoy the experience fully.
 
 ## Challenge:
 **Swipe left** to activate Newton's high powered ejection seat and direct him into the haystack.
 
 _ _ _
 
 * Experiment:
 You can now change the force at which the ejection seat operates using `lowEjectionForce()`, `mediumEjectionForce()` and `highEjectionForce()`. Experiment with different forces and gravities to observe different behaviours.
 
 
 * Callout(**Remember**):
 If all the controls available sound confusing, below is a list to help you. Have fun!
 
 /*:
 + **Tap the screen to accelerate the carriage**
 + **Swipe left to activate the ejection seat**
 + Change planet: `planetMars()` and `planetEarth()`
 + Change the weight of the cart: `lowWeight()`, `mediumWeight()` and `heavyWeight()`
 + Change the ejection force: `lowEjectionForce()`, `mediumEjectionForce()` and `highEjectionForce()`
 + Change the force acting on the cart: `lowForce()`, `mediumForce()` and `highForce()`
 */
 //#-hidden-code
 */
//#-end-hidden-code

 //#-hidden-code
 //#-code-completion(everything, hide)
 import Foundation
 import PlaygroundSupport
 import SpriteKit
 import Foundation
 import PlaygroundSupport
 import SpriteKit
 
 
 
 
 enum currentPlanet {
 case earth
 case mars
 }
 
 let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 2732, height: 2048))
 var presentedScene = SKScene()
 var typeOfPlanet = currentPlanet.mars
 presentedScene = GameScene4(fileNamed: "GameScene4")!
 func planetEarth() {
 presentedScene = GameScene8(fileNamed: "GameScene8")!
 typeOfPlanet = .earth
 }
 func planetMars() {
 presentedScene = GameScene4(fileNamed: "GameScene4")!
 typeOfPlanet = .mars
 }
 
 func lightWeight() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeCartNode(numberOfCarriage: 1)
 presentedScene = myScene
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeCartNode(numberOfCarriage: 1)
 presentedScene = myScene
 }
 
 }
 
 }
 func mediumWeight() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeCartNode(numberOfCarriage: 2)
 presentedScene = myScene
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeCartNode(numberOfCarriage: 2)
 presentedScene = myScene
 }
 }
 
 }
 func heavyWeight() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeCartNode(numberOfCarriage: 3)
             presentedScene = myScene
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeCartNode(numberOfCarriage: 3)
             presentedScene = myScene
 }
 }
 
 }
 func highForce() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeForce(numberOfForce: 3)
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeForce(numberOfForce: 3)
 }
 }
 }
 func mediumForce() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeForce(numberOfForce: 2)
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeForce(numberOfForce: 2)
 }
 }
 }
 func lowForce() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeForce(numberOfForce: 1)
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeForce(numberOfForce: 1)
 }
 }
 }
 func highEjectionForce() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeEjection(numberOfForce: 3)
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeEjection(numberOfForce: 3)
 }
 }
 }
 func mediumEjectionForce() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeEjection(numberOfForce: 2)
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeEjection(numberOfForce: 2)
 }
 }
 }
 func lowEjectionForce() {
 switch typeOfPlanet {
 case .earth:
 if let myScene = presentedScene as? GameScene8 {
 myScene.changeEjection(numberOfForce: 2)
 }
 case .mars:
 if let myScene = presentedScene as? GameScene4 {
 myScene.changeEjection(numberOfForce: 2)
 }
 }
 }
 
 
 //PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
 
 planetMars()
 mediumWeight()
 
 
 //#-end-hidden-code
 //#-code-completion(everything, hide)
 //#-code-completion(identifier, show, planetEarth(), planetMars(), lightWeight(), mediumWeight(), heavyWeight(), lowForce(), mediumForce(), highForce(), lowEjectionForce(), mediumEjectionForce(), highEjectionForce())
 //#-editable-code Tap to enter code
 
 
 //#-end-editable-code
 //#-hidden-code
 presentedScene.scaleMode = .aspectFit
 sceneView.presentScene(presentedScene)
 PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
 //#-end-hidden-code
 
