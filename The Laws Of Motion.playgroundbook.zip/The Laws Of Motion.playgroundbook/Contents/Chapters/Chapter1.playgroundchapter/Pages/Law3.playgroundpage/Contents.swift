
/*:
 
 * Callout(**Law 3**):
 _For every action there is an equal and opposite reaction._
 
 While this law is harder to observe in real life, it is taking place everywhere around us!
 
 ## Challenge:
 **Swipe left** to activate Newton's high powered ejection seat and direct him into the haystack.
 
 Can you see the action and reaction? When ejecting, Newton goes forward, while the carriage goes in the opposite direction. It is that simple!
 _ _ _
 
 * Experiment:
 You can now change the force at which the ejection seat operates using `lowEjectionForce()`, `mediumEjectionForce()` and `highEjectionForce()`. Experiment with different forces and gravities to observe different behaviours.
 
 Can you guess why the ejection seat travels further on Mars? If your answer is gravity, you are correct!
 
 
 - Note:
 You can still change planets and tap apples to observe the differences.
 
 [**Next Page**](@next)
 
 */
//#-hidden-code
//#-code-completion(everything, hide)
import Foundation
import PlaygroundSupport
import SpriteKit




enum currentPlanet {
    case earth
    case mars
}

let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 2732, height: 2048))
var presentedScene = SKScene()
var typeOfPlanet = currentPlanet.mars
func planetEarth() {
    presentedScene = GameScene7(fileNamed: "GameScene7")!
    typeOfPlanet = .earth
}
func planetMars() {
    presentedScene = GameScene3(fileNamed: "GameScene3")!
    typeOfPlanet = .mars
}

func highEjectionForce() {
    switch typeOfPlanet {
    case .earth:
        if let myScene = presentedScene as? GameScene7 {
            myScene.changeEjection(numberOfForce: 3)
        }
    case .mars:
        if let myScene = presentedScene as? GameScene3 {
            myScene.changeEjection(numberOfForce: 3)
        }
    }
}
func mediumEjectionForce() {
    switch typeOfPlanet {
    case .earth:
        if let myScene = presentedScene as? GameScene7 {
            myScene.changeEjection(numberOfForce: 2)
        }
    case .mars:
        if let myScene = presentedScene as? GameScene3 {
            myScene.changeEjection(numberOfForce: 2)
        }
    }
}
func lowEjectionForce() {
    switch typeOfPlanet {
    case .earth:
        if let myScene = presentedScene as? GameScene7 {
            myScene.changeEjection(numberOfForce: 1)
        }
    case .mars:
        if let myScene = presentedScene as? GameScene3 {
            myScene.changeEjection(numberOfForce: 1)
        }
    }
}


planetMars()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, planetEarth(), planetMars(), highEjectionForce(), mediumEjectionForce(), lowEjectionForce())
//#-editable-code Tap to enter code


//#-end-editable-code
//#-hidden-code
presentedScene.scaleMode = .aspectFit
sceneView.presentScene(presentedScene)
PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
