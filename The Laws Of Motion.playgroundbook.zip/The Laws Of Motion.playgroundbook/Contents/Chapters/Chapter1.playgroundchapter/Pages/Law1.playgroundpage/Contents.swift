
/*:
 
 Welcome to a quick tour through physics and coding.
 
 It is year 2100, young Isaac Newton Jr.  the 8th is reading a book about the distruction of humankind on planet Earth. He is reading a book about the laws discovered by his father.
 
 * Callout(**Law 1**):
 _An object will remain at rest or in uniform motion in a straight line unless acted upon by an external force._
 
 
 ## Challenge:
 Click `Run My Code` to see the moment when Isaac Newton made this discovery. Apply a force on the apples to observe how they change state. When you do this, an external force is applied to break the apple away. When the apple breaks away, a force called gravity shows its strength and makes the apples fall.
 
 
 * Experiment:
 Now try to change things up. See how Isaac's father first made this discovery. Use functions `planetEarth()` and `planetMars()` to toggle between these two planets. Notice how the apples are falling in different ways on planets?
 
 Once you're finished just go to the next page for Law 2.
 
 [**Next Page**](@next)
 
 */
//#-hidden-code
//#-code-completion(everything, hide)

import SpriteKit
import PlaygroundSupport


let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 2732, height: 2048))

func planetEarth() {
    if let scene = GameScene5(fileNamed: "GameScene5") {
        scene.scaleMode = .aspectFit
        sceneView.presentScene(scene)
    }
}
func planetMars() {
    if let scene = GameScene1(fileNamed: "GameScene1") {
        scene.scaleMode = .aspectFit
        sceneView.presentScene(scene)
    }
}

planetMars()


PlaygroundSupport.PlaygroundPage.current.liveView = sceneView

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, planetEarth(), planetMars())
//#-editable-code Tap to enter code


//#-end-editable-code

