
/*:
 
 * Callout(**Law 2**):
 _An object will remain at rest or in uniform motion in a straight line unless acted upon by an external force._
 
 This basically means that the force which a body is experiencing is proportional to its mass and acceleration, or: 
 _Force = Mass X Acceleration_
 
 ## Challenge:
 **Tap the screen** to apply a force on the cart and observe Law 2. You can now also change carriage weights using the `lightweight()`, `mediumWeight()` and `heavyWeight()` functions.
 
 Notice how heavier objects tend to accelerate slower? This is because we are applying the same force to a an object with a larger mass, which translates to a lower acceleration.
 _ _ _
 
 You may also notice that on Mars objects move faster than on Earth. Remember gravity from the  previous page? Earth's gravity is almost _three times_ stronger than Mars's. This means that an objects weighing 3kg on Earth weighs three times more than on Mars. This is why carts move faster on Mars.
 
 
 - Note:
 You can still change planets and tap apples to observe the differences.
 
 [**Next Page**](@next)
 
 */
//#-hidden-code
//#-code-completion(everything, hide)
import Foundation
import PlaygroundSupport
import SpriteKit




enum currentPlanet {
    case earth
    case mars
}

let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 2732, height: 2048))
var presentedScene = SKScene()
var typeOfPlanet = currentPlanet.mars
func planetEarth() {
    presentedScene = GameScene6(fileNamed: "GameScene6")!
    typeOfPlanet = .earth
}
func planetMars() {
    presentedScene = GameScene2(fileNamed: "GameScene2")!
    typeOfPlanet = .mars
}


func lightWeight() {
    switch typeOfPlanet {
    case .earth:
        if let myScene = presentedScene as? GameScene6 {
            myScene.changeCartNode(numberOfCarriage: 1)
            presentedScene = myScene
        }
    case .mars:
        if let myScene = presentedScene as? GameScene2 {
            myScene.changeCartNode(numberOfCarriage: 1)
            presentedScene = myScene
        }
        
    }
    
}
func mediumWeight() {
    switch typeOfPlanet {
    case .earth:
        if let myScene = presentedScene as? GameScene6 {
            myScene.changeCartNode(numberOfCarriage: 2)
            presentedScene = myScene
        }
    case .mars:
        if let myScene = presentedScene as? GameScene2 {
            myScene.changeCartNode(numberOfCarriage: 2)
            presentedScene = myScene
        }
    }
    
}
func heavyWeight() {
    switch typeOfPlanet {
    case .earth:
        if let myScene = presentedScene as? GameScene6 {
            myScene.changeCartNode(numberOfCarriage: 3)
                        presentedScene = myScene
        }
    case .mars:
        if let myScene = presentedScene as? GameScene2 {
            myScene.changeCartNode(numberOfCarriage: 3)
                        presentedScene = myScene
        }
    }
    
}


//PlaygroundSupport.PlaygroundPage.current.liveView = sceneView

planetMars()
mediumWeight()


//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, planetEarth(), planetMars(), lightWeight(), mediumWeight(), heavyWeight())
//#-editable-code Tap to enter code


//#-end-editable-code
//#-hidden-code
presentedScene.scaleMode = .aspectFit
sceneView.presentScene(presentedScene)
PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
